

/* ---------------------------------------------------------
   PHASE 1 —  Data Quality Checks
--------------------------------------------------------- */
-- Duplicate Transaction Check
SELECT
   `﻿transaction_id`,
    COUNT(*) AS duplicate_count
FROM Transactions
GROUP BY `﻿transaction_id`
HAVING COUNT(*) > 1; -- no duplicates detect

-- Check missing values
SELECT
    SUM(transaction_date IS NULL) AS missing_date,
    SUM(transaction_time IS NULL) AS missing_time,
    SUM(store_id IS NULL) AS missing_store_id,
    SUM(product_id IS NULL) AS missing_product_id,
    SUM(transaction_qty IS NULL) AS missing_qty,
    SUM(unit_price IS NULL) AS missing_price,
    SUM(amount IS NULL) AS missing_amount
FROM transactions; -- no null values 

-- Negative or zero values
SELECT *
FROM transactions
WHERE 
    transaction_qty <= 0
    OR unit_price <= 0
    OR amount <= 0;

-- Quantity = 0 but Amount > 0 
SELECT *
FROM transactions
WHERE transaction_qty = 0 AND amount > 0;

-- Invalid hour values
SELECT *
FROM transactions
WHERE hour NOT BETWEEN 0 AND 23; 

-- checking nvalid month or weekday
SELECT *
FROM transactions
WHERE 
    month NOT BETWEEN 1 AND 12
    OR day_of_week NOT BETWEEN 1 AND 7; -- detect the week start from 0 
 
UPDATE transactions
SET day_of_week =
    CASE day_name
        WHEN 'Monday' THEN 1
        WHEN 'Tuesday' THEN 2
        WHEN 'Wednesday' THEN 3
        WHEN 'Thursday' THEN 4
        WHEN 'Friday' THEN 5
        WHEN 'Saturday' THEN 6
        WHEN 'Sunday' THEN 7
    END;
    
-- checking Empty strings
SELECT
    SUM(store_location = '' OR store_location IS NULL) AS empty_store_location,
    SUM(product_category = '' OR product_category IS NULL) AS empty_category,
    SUM(product_type = '' OR product_type IS NULL) AS empty_type,
    SUM(size = '' OR size IS NULL) AS empty_size
FROM transactions;

-- Trim whitespace
UPDATE transactions
SET 
    store_location = TRIM(store_location),
    product_category = TRIM(product_category),
    product_type = TRIM(product_type),
    size = TRIM(size);


-- Detect inconsistent capitalization
SELECT DISTINCT product_category FROM transactions ORDER BY product_category;
SELECT DISTINCT size FROM transactions ORDER BY size;    

-- Validate amount = qty × unit price
SELECT *
FROM Transactions
WHERE amount != transaction_qty * unit_price;

-- Detect outliers
SELECT *
FROM Transactions
WHERE unit_price < 10 OR unit_price > 800;

/* ---------------------------------------------------------
   PHASE 2 — Descriptive Analytics 
--------------------------------------------------------- */

-- Total Revenu , Total qty Sold , Total Transactions, Avg Amount per transaction
SELECT SUM(amount) AS total_revenue,
       SUM(transaction_qty) AS total_qty_sold,
       COUNT(`﻿transaction_id`) AS total_transactions,
       AVG(amount) AS avg_transaction_value
FROM transactions;

-- Revenue per product category
SELECT product_category, 
       SUM(amount) AS revenue_category,
       SUM(transaction_qty) AS total_qty_category
FROM transactions
GROUP BY product_category
ORDER BY revenue_category DESC;

-- Revenue per product type & size
SELECT product_type, size,
       SUM(amount) AS revenue_type_size,
       SUM(transaction_qty) AS total_qty_type_size
FROM transactions
GROUP BY product_type, size
ORDER BY revenue_type_size DESC;

-- ------------ Time Series Analysis --------------

-- monthly Revenue per Store
SELECT store_location,
       Month_Name,
       SUM(amount) AS daily_revenue,
       COUNT('transaction_id') AS daily_transactions
FROM transactions
GROUP BY store_location, Month_Name
ORDER BY Month_Name, daily_revenue DESC;

-- Monthly Revenue per Product Category
SELECT month_name, product_category,
       SUM(amount) AS monthly_revenue,
       SUM(transaction_qty) AS total_qty_sold
FROM transactions
GROUP BY month_name, product_category
ORDER BY month_name, monthly_revenue DESC;

-- Product Type & Size Revenue Efficiency
SELECT product_type, size,
       SUM(amount) AS total_revenue,
       SUM(transaction_qty) AS total_qty,
       ROUND(SUM(amount)/SUM(transaction_qty),2) AS revenue_per_unit
FROM transactions
GROUP BY product_type, size
ORDER BY revenue_per_unit DESC;

-- Day-of-Week Revenue per Store
SELECT day_name, store_location,
       SUM(amount) AS revenue,
       COUNT(`﻿transaction_id`) AS transactions_count
FROM transactions
GROUP BY day_name, store_location
ORDER BY day_name, revenue DESC;

-- Monthly Revenue by Size
SELECT month_name, size,
       SUM(amount) AS revenue,
       SUM(transaction_qty) AS total_qty
FROM transactions
GROUP BY month_name, size
ORDER BY month_name, revenue DESC;

-- -------------- Customer Behavior Patterns ------------------
-- Peak Hour Sales
SELECT hour, 
       COUNT(transaction_id) AS transaction_count,
       SUM(amount) AS revenue_per_hour
FROM transactions
GROUP BY hour
ORDER BY transaction_count DESC;

-- Day-of-Week Performance
SELECT day_of_week, day_name,
       SUM(amount) AS revenue_per_day,
       COUNT(`﻿transaction_id`) AS transaction_count
FROM transactions
GROUP BY day_of_week, day_name
ORDER BY day_of_week; 

-- -----------------Store Performance Analysis --------------

-- Store Ranking by Revenue
SELECT 
    store_location,
    SUM(amount) AS revenue,
    RANK() OVER (ORDER BY SUM(amount) DESC) AS revenue_rank
FROM Transactions
GROUP BY store_location;

-- Month-over-month growth
SELECT month_name,
       SUM(amount) AS monthly_revenue,
       LAG(SUM(amount)) OVER (ORDER BY month) AS prev_month_revenue,
       ROUND((SUM(amount) - LAG(SUM(amount)) OVER (ORDER BY month))
             / LAG(SUM(amount)) OVER (ORDER BY month) * 100,2) AS growth_percentage
FROM transactions
GROUP BY month, month_name
ORDER BY month;



-- Store contribution %
SELECT store_id, store_location,
       SUM(amount) AS store_revenue,
       ROUND(SUM(amount)/ (SELECT SUM(amount) FROM transactions) * 100,2) AS contribution_pct
FROM transactions
GROUP BY store_id, store_location
ORDER BY contribution_pct DESC;

-- ---------------------- Product Performance --------------------------

-- Product Mix % by Size 
SELECT 
    size,
    COUNT(*) AS orders,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM Transactions), 2) AS percentage
FROM Transactions
GROUP BY size
ORDER BY percentage DESC;

-- Top 10 Best Selling Products
SELECT 
    product_detail,
    SUM(amount) AS revenue
FROM Transactions
GROUP BY product_detail
ORDER BY revenue DESC
LIMIT 10;

-- Revenue Contribution % by Category 
SELECT 
    product_category,
    SUM(amount) AS category_sales,
    ROUND(SUM(amount) * 100.0 / (SELECT SUM(amount) FROM Transactions), 2) AS contribution_percent
FROM Transactions
GROUP BY product_category
ORDER BY category_sales DESC;

-- Product efficiency (
SELECT product_id, product_category,
       SUM(amount)/SUM(transaction_qty) AS revenue_per_unit,
       SUM(transaction_qty) AS total_qty
FROM transactions
GROUP BY product_id, product_category
ORDER BY revenue_per_unit DESC;

-- Product Contribution % (Top Revenue Items)
WITH ranked AS (
    SELECT 
        product_detail,
        SUM(amount) AS revenue
    FROM Transactions
    GROUP BY product_detail
)
SELECT 
    product_detail,
    revenue,
    ROUND(revenue * 100.0 / (SELECT SUM(amount) FROM Transactions), 2) AS contribution_percent
FROM ranked
ORDER BY revenue DESC
LIMIT 10;

-- Slow-moving products (bottom 10%)
SELECT product_id, product_category,
       SUM(transaction_qty) AS total_qty_sold
FROM transactions
GROUP BY product_id, product_category
ORDER BY total_qty_sold ASC
LIMIT 10;
